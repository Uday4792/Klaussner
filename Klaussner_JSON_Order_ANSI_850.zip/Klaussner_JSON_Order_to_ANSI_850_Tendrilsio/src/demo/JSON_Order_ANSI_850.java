package demo;

// Java program to read JSON from a file 
  
import java.io.FileReader;
import java.io.FileWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Iterator; 
import java.util.Map; 
  
import org.json.simple.JSONArray; 
import org.json.simple.JSONObject; 
import org.json.simple.parser.*; 
  
public class JSON_Order_ANSI_850  
{ 
    public static void main(String[] args) throws Exception  
    { 
        Object obj = new JSONParser().parse(new FileReader("TesFileJSONForJava.json")); 
        FileWriter myWriter = new FileWriter("PO_CSV_ANSI_850.txt");
        JSONObject jo = (JSONObject) obj; 
        String streetAddress = "",city = "",state = "",sku = "",description = "";
        Integer LINE_COUNT=0;
        double rate = 0;
        long quantity = 0;
        
        //Get Current Date and Time
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
        LocalDateTime now = LocalDateTime.now(); 
        String CurrentDate = dtf.format(now).substring(0, 10);
        String CurrentTime = dtf.format(now).substring(10, 19).replaceAll(":", "").substring(1,5);
        System.out.println(CurrentTime);
          
        // getting address 
        Map address = ((Map)jo.get("delivery_address")); 
        Iterator<Map.Entry> itr1 = address.entrySet().iterator(); 
        while (itr1.hasNext()) { 
            Map.Entry pair = itr1.next(); 
            //System.out.println(pair.getKey() + " : " + pair.getValue()); 
            if(pair.getKey().equals("streetAddress"))
            {
            	streetAddress = (String) pair.getValue();
            }
            if(pair.getKey().equals("city"))
            {
            	city = (String) pair.getValue();
            }
            if(pair.getKey().equals("state"))
            {
            	state = (String) pair.getValue();
            }
        } 
        
        Map billing_address = ((Map)jo.get("billing_address")); 
        Iterator<Map.Entry> itr3 = billing_address.entrySet().iterator(); 
        while (itr3.hasNext()) { 
            Map.Entry pair1 = itr3.next(); 
            //System.out.println(pair1.getKey() + " : " + pair1.getValue()); 
        } 

      
        String date = (String) jo.get("date");
        String discount_amount_formatted = (String) jo.get("discount_amount_formatted");
        String tax_total = (String) jo.get("tax_total");
        String delivery_org_address_id = (String) jo.get("delivery_org_address_id");
        String adjustment_formatted = (String) jo.get("adjustment_formatted");
        String is_discount_before_tax = (String) jo.get("is_discount_before_tax");
        String discount_amount = (String) jo.get("discount_amount");
        String purchaseorder_id = (String) jo.get("purchaseorder_id");
        String expected_delivery_date = (String) jo.get("expected_delivery_date");
        String discount_account_id = (String) jo.get("discount_account_id");
        String discount = (String) jo.get("discount");
        String currency_code = (String) jo.get("currency_code");
        String total = (String) jo.get("total");
        String expected_delivery_date_formatted = (String) jo.get("expected_delivery_date_formatted");
        String tax_total_formatted = (String) jo.get("tax_total_formatted");
        String date_formatted = (String) jo.get("date_formatted");
        String sub_total_formatted = (String) jo.get("sub_total_formatted");
        //String custom_field_hash = (String) jo.get("custom_field_hash");
        String adjustment_description = (String) jo.get("adjustment_description");
        String delivery_customer_id = (String) jo.get("delivery_customer_id");
        String exchange_rate = (String) jo.get("exchange_rate");
        String currency_symbol = (String) jo.get("currency_symbol");
        //String custom_fields = (String) jo.get("custom_fields");
        String ship_via_id = (String) jo.get("ship_via_id");
        String vendor_name = (String) jo.get("vendor_name");
        String status_formatted = (String) jo.get("status_formatted");
        String reference_number = (String) jo.get("reference_number");
        String purchaseorder_number = (String) jo.get("purchaseorder_number");
        String delivery_date = (String) jo.get("delivery_date");
        String delivery_date_formatted = (String) jo.get("delivery_date_formatted");
        String vendor_id = (String) jo.get("vendor_id");
        String sub_total = (String) jo.get("sub_total");
        String ship_via = (String) jo.get("ship_via");
        String attention = (String) jo.get("attention");
        String adjustment = (String) jo.get("adjustment");
        String total_formatted = (String) jo.get("total_formatted");
        String currency_id = (String) jo.get("currency_id");
        String status = (String) jo.get("status");


        JSONArray ja = (JSONArray) jo.get("line_items"); 
        Iterator itr2 = ja.iterator(); 
      
        
//-------------------------------Write in Output--------------------------------------------------------------
        String LineDelimeter = "\r\n";
        String FieldDelimeter = "*";
        String ISA_SENDER_ID = "Uday123        ";
        String ISA_RECIEVER_ID = "Uday321        ";
		
        myWriter.write("ISA"+ FieldDelimeter +"00"+ FieldDelimeter +" "+ FieldDelimeter +"00"+ FieldDelimeter +" "+ FieldDelimeter +"ZZ"+ FieldDelimeter +ISA_SENDER_ID+ FieldDelimeter +"ZZ"+ FieldDelimeter +ISA_RECIEVER_ID+ FieldDelimeter + CurrentDate.replaceAll("/", "").substring(2) + FieldDelimeter + CurrentTime + FieldDelimeter +"U"+ FieldDelimeter +"00401"+ FieldDelimeter +"000005007"+ FieldDelimeter +"0"+ FieldDelimeter +"T"+ FieldDelimeter +":~");
        myWriter.write(LineDelimeter);
        
        myWriter.write("GS"+ FieldDelimeter +"PO"+ FieldDelimeter +"Uday123"+ FieldDelimeter +"Uday321"+ FieldDelimeter +CurrentDate.replaceAll("/", "") + FieldDelimeter +CurrentTime+ FieldDelimeter +"5007"+ FieldDelimeter +"T"+ FieldDelimeter +"004010~");
        myWriter.write(LineDelimeter);
            
            myWriter.write("ST"+ FieldDelimeter +"850"+ FieldDelimeter +"0001~");
            myWriter.write(LineDelimeter);
            
            myWriter.write("BEG"+ FieldDelimeter +"00"+ FieldDelimeter +"SA"+ FieldDelimeter +""+ purchaseorder_id + ""+ FieldDelimeter +""+ FieldDelimeter +"" + date.replaceAll("-", "") +  "~");
            myWriter.write(LineDelimeter);
            
            myWriter.write("CUR"+ FieldDelimeter +"SN"+ FieldDelimeter +"" + currency_code + "~");
            myWriter.write(LineDelimeter);
            
            myWriter.write("DTM"+ FieldDelimeter +"002"+ FieldDelimeter +"" +  date.replaceAll("-", ""));
            myWriter.write(LineDelimeter);
            
            myWriter.write("MSG"+ FieldDelimeter +"" + "TBD" + "~");
            myWriter.write(LineDelimeter);
            
            myWriter.write("N1"+ FieldDelimeter +"ST"+ FieldDelimeter +""+ "TBD" + ""+ FieldDelimeter +"92"+ FieldDelimeter +"01~");
            myWriter.write(LineDelimeter);
            
            myWriter.write("N3"+ FieldDelimeter +"" + streetAddress + "~");
            myWriter.write(LineDelimeter);
            
            myWriter.write("N4"+ FieldDelimeter +"" + city + ""+ FieldDelimeter +""+ state + ""+ FieldDelimeter +"" + "US" +"~");
            myWriter.write(LineDelimeter);
            
            while (itr2.hasNext())  
            { 
                itr1 = ((Map) itr2.next()).entrySet().iterator(); 
                LINE_COUNT = LINE_COUNT + 1;
                System.out.println("------------------------------------------------------------------\n");
                while (itr1.hasNext()) 
                { 
                    Map.Entry pair = itr1.next(); 
                    //System.out.println(pair.getKey() + " : " + pair.getValue()); 
                    if(pair.getKey().equals("quantity")) 
                    {
                    	quantity = (long) pair.getValue();
                    }
                    if(pair.getKey().equals("rate")) 
                    {
                    	rate = (double) pair.getValue();
                    }
                    if(pair.getKey().equals("sku")) 
                    {
                    	sku = (String) pair.getValue();
                    }
                    if(pair.getKey().equals("description")) 
                    {
                    	description = (String) pair.getValue();
                    }
                } 
            
            myWriter.write("PO1"+ FieldDelimeter +"1"+ FieldDelimeter +"" + quantity + ""+ FieldDelimeter +"" + ""+ FieldDelimeter +"EA"+ FieldDelimeter +"" + rate +""+ FieldDelimeter +"PE"+ FieldDelimeter +"SK"+ FieldDelimeter +"" + sku + ""+ FieldDelimeter +"VC"+ FieldDelimeter +""+ sku + "~");
            myWriter.write(LineDelimeter);
            
            myWriter.write("PID"+ FieldDelimeter +"F"+ FieldDelimeter +""+ FieldDelimeter +""+ FieldDelimeter +""+ FieldDelimeter +""+ description +"~");
            myWriter.write(LineDelimeter);
            }
            myWriter.write("CTT"+ FieldDelimeter + LINE_COUNT + "~");
            myWriter.write(LineDelimeter);

        
        myWriter.write("SE"+ FieldDelimeter + (2*LINE_COUNT + 10) + FieldDelimeter +"0001~");
        myWriter.write(LineDelimeter);
        
        myWriter.write("GE"+ FieldDelimeter +"1"+ FieldDelimeter +"5007~");
        myWriter.write(LineDelimeter);
        
        myWriter.write("IEA"+ FieldDelimeter +"1"+ FieldDelimeter +"000005007~");
        myWriter.write(LineDelimeter);
        
        
        myWriter.close();
//-------------------------------Write in Output Ends--------------------------------------------------------        

        
    } 
} 